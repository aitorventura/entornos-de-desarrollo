package alquiler;

public interface VehiculoRepository {

    /** Devuelve true si hay al menos una unidad disponible del tipo indicado. */
    boolean estaDisponible(String tipoVehiculo);

    /** Devuelve los kilómetros del vehículo disponible (para aplicar descuento por uso). */
    int getKilometros(String tipoVehiculo);
}
