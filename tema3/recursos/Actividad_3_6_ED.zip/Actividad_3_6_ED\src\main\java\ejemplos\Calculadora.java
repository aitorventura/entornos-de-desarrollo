package ejemplos;

/**
 * Calculadora de operaciones aritméticas básicas sobre enteros.
 *
 * Los métodos que pueden producir un resultado indefinido (como dividir entre cero)
 * lanzan una excepción en lugar de devolver un valor especial, para que el error
 * sea imposible de ignorar.
 */
public class Calculadora {

    /**
     * Suma dos enteros.
     *
     * @param a sumando
     * @param b sumando
     * @return a + b
     */
    public int sumar(int a, int b) {
        return a + b;
    }

    /**
     * Resta el segundo entero al primero.
     *
     * @param a minuendo
     * @param b sustraendo
     * @return a - b
     */
    public int restar(int a, int b) {
        return a - b;
    }

    /**
     * Multiplica dos enteros.
     *
     * @param a factor
     * @param b factor
     * @return a * b
     */
    public int multiplicar(int a, int b) {
        return a * b;
    }

    /**
     * Divide el primer entero entre el segundo (división entera).
     *
     * @param a dividendo
     * @param b divisor — no puede ser 0
     * @return parte entera de a / b
     * @throws ArithmeticException si b es 0
     */
    public int dividir(int a, int b) {
        if (b == 0) throw new ArithmeticException("División entre cero");
        return a / b;
    }

    /**
     * Indica si un número es par.
     *
     * @param n número a comprobar — debe ser >= 0
     * @return true si n es par, false si es impar
     * @throws IllegalArgumentException si n es negativo
     */
    public boolean esPar(int n) {
        if (n < 0) throw new IllegalArgumentException("El número no puede ser negativo: " + n);
        return n % 2 == 0;
    }

    /**
     * Calcula la potencia entera de una base.
     *
     * @param base      base de la potencia
     * @param exponente exponente — debe ser >= 0
     * @return base elevada al exponente
     * @throws IllegalArgumentException si el exponente es negativo
     */
    public int potencia(int base, int exponente) {
        if (exponente < 0) throw new IllegalArgumentException("El exponente no puede ser negativo: " + exponente);
        int resultado = 1;
        for (int i = 0; i < exponente; i++) resultado *= base;
        return resultado;
    }
}
