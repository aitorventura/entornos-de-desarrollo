package ejemplos;

/**
 * Operaciones compuestas que delegan los cálculos atómicos en {@link Calculadora}.
 *
 * Esta clase existe para ilustrar el patrón de inyección de dependencias:
 * recibe la Calculadora por constructor en lugar de crearla ella misma.
 * Eso permite sustituirla por un mock en los tests, de modo que
 * CalculadoraServiceTest verifica solo la lógica de este servicio
 * sin depender de la implementación real de Calculadora.
 */
public class CalculadoraService {

    private final Calculadora calculadora;

    /**
     * @param calculadora instancia de Calculadora que este servicio usará internamente
     */
    public CalculadoraService(Calculadora calculadora) {
        this.calculadora = calculadora;
    }

    /**
     * Calcula el doble de la suma de dos números: (a + b) * 2.
     *
     * @param a primer operando
     * @param b segundo operando
     * @return (a + b) * 2
     */
    public int dobleDeLaSuma(int a, int b) {
        int suma = calculadora.sumar(a, b);
        return calculadora.multiplicar(suma, 2);
    }

    /**
     * Calcula el cuadrado de la diferencia entre dos números: (a - b)².
     *
     * @param a minuendo
     * @param b sustraendo
     * @return (a - b)²
     */
    public int restaAlCuadrado(int a, int b) {
        int diferencia = calculadora.restar(a, b);
        // Se pasa la diferencia como ambos factores para que el test pueda
        // verificar que el servicio llama a multiplicar(diferencia, diferencia).
        return calculadora.multiplicar(diferencia, diferencia);
    }

    /**
     * Suma dos números y divide el resultado entre un divisor: (a + b) / divisor.
     *
     * @param a       primer sumando
     * @param b       segundo sumando
     * @param divisor número por el que se divide la suma — no puede ser 0
     * @return (a + b) / divisor (división entera)
     * @throws ArithmeticException si el divisor es 0 (propagado desde Calculadora)
     */
    public int sumaYDivide(int a, int b, int divisor) {
        int suma = calculadora.sumar(a, b);
        return calculadora.dividir(suma, divisor);
    }
}
