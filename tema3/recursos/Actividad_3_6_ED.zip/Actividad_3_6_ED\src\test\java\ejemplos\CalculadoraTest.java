package ejemplos;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests parametrizados para {@link Calculadora}.
 *
 * Los tests parametrizados evitan repetir el mismo bloque de código una vez por cada
 * combinación de datos. Se define la tabla de valores una sola vez y JUnit ejecuta
 * el método de test una vez por fila.
 *
 * @ValueSource — un único parámetro por fila (lista de valores del mismo tipo).
 * @CsvSource   — varios parámetros por fila, separados por coma; útil cuando se
 *                necesita pasar entrada + resultado esperado juntos.
 */
class CalculadoraTest {

    private Calculadora calc;

    @BeforeEach
    void setUp() {
        calc = new Calculadora();
    }

    // -------------------------------------------------------------------------
    // sumar
    // -------------------------------------------------------------------------

    /**
     * Cada fila de @CsvSource genera una ejecución independiente del test.
     * El tercer valor de cada fila es el resultado esperado.
     */
    @ParameterizedTest
    @CsvSource({
        " 2,  3,  5",   // positivos normales
        " 0,  0,  0",   // ambos cero
        "-1, -2, -3",   // ambos negativos
        " 5, -3,  2",   // positivo + negativo
        "-5,  3, -2"    // negativo + positivo
    })
    void sumar_devuelveResultadoCorrecto(int a, int b, int esperado) {
        assertEquals(esperado, calc.sumar(a, b));
    }

    // -------------------------------------------------------------------------
    // dividir
    // -------------------------------------------------------------------------

    @ParameterizedTest
    @CsvSource({
        "10, 2, 5",
        " 9, 3, 3",
        " 7, 2, 3",   // división entera: 7/2 = 3, no 3.5
        " 0, 5, 0"
    })
    void dividir_devuelveParticionEntera(int a, int b, int esperado) {
        assertEquals(esperado, calc.dividir(a, b));
    }

    @Test
    void dividir_entreCero_lanzaArithmeticException() {
        assertThrows(ArithmeticException.class, () -> calc.dividir(10, 0));
    }

    // -------------------------------------------------------------------------
    // esPar
    // -------------------------------------------------------------------------

    // @ValueSource es suficiente porque solo hay un parámetro de entrada;
    // no necesitamos columna de resultado esperado, siempre esperamos true.
    @ParameterizedTest
    @ValueSource(ints = {0, 2, 8, 100})
    void esPar_numeroPar_devuelveTrue(int n) {
        assertTrue(calc.esPar(n));
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 7, 99})
    void esPar_numeroImpar_devuelveFalse(int n) {
        assertFalse(calc.esPar(n));
    }

    @ParameterizedTest
    @ValueSource(ints = {-1, -4})
    void esPar_numeroNegativo_lanzaIllegalArgumentException(int n) {
        assertThrows(IllegalArgumentException.class, () -> calc.esPar(n));
    }

    // -------------------------------------------------------------------------
    // potencia
    // -------------------------------------------------------------------------

    @ParameterizedTest
    @CsvSource({
        "2, 0,  1",   // cualquier número elevado a 0 = 1
        "2, 1,  2",
        "2, 3,  8",
        "3, 3, 27",
        "5, 2, 25"
    })
    void potencia_devuelveResultadoCorrecto(int base, int exponente, int esperado) {
        assertEquals(esperado, calc.potencia(base, exponente));
    }

    @Test
    void potencia_exponenteNegativo_lanzaIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> calc.potencia(2, -1));
    }
}
