package alquiler;

public class CalculadoraTarifa {

    /**
     * Calcula el precio total del alquiler.
     *
     * @param tipoVehiculo "COCHE", "MOTO" o "FURGONETA"
     * @param dias         número de días [1 .. 365]
     * @param seguro       true = incluir seguro (+15% sobre el precio base)
     * @return precio total (> 0.0), o -1.0 si algún parámetro es inválido
     *
     * Tarifas base por día:
     *   COCHE     → 40.00 €
     *   MOTO      → 25.00 €
     *   FURGONETA → 65.00 €
     */
    public double calcularPrecio(String tipoVehiculo, int dias, boolean seguro) {
        // TODO: implementar
        return 0;
    }
}
