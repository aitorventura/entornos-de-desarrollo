package ejemplos;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Tests con Mockito para {@link CalculadoraService}.
 *
 * CalculadoraService depende de Calculadora. Si usáramos la calculadora real
 * y esta tuviera un bug, los tests de CalculadoraService también fallarían,
 * aunque la lógica del servicio sea correcta. Con un mock controlamos exactamente
 * qué devuelve Calculadora y así el test verifica solo la lógica del propio servicio.
 *
 * Patrón de cada test:
 *   1. Arrange — configurar el mock con when(...).thenReturn(...)
 *   2. Act     — llamar al método que se quiere probar
 *   3. Assert  — verificar el resultado con assertEquals
 *   4. Verify  — comprobar que el servicio llamó al mock con los argumentos correctos
 */
class CalculadoraServiceTest {

    // El mock intercepta cada llamada a Calculadora y devuelve lo que le configuremos.
    private Calculadora mockCalculadora;
    private CalculadoraService servicio;

    @BeforeEach
    void setUp() {
        // mock() crea un objeto "falso" de la clase indicada.
        // Cada llamada a sus métodos devuelve 0 por defecto hasta que se configure con when().
        mockCalculadora = mock(Calculadora.class);
        servicio = new CalculadoraService(mockCalculadora);
    }

    // -------------------------------------------------------------------------
    // dobleDeLaSuma
    // -------------------------------------------------------------------------

    @Test
    void dobleDeLaSuma_llamaASumarYMultiplicar_devuelveResultadoCorrecto() {
        // Arrange: indicamos qué devuelve el mock para esos argumentos concretos
        when(mockCalculadora.sumar(3, 2)).thenReturn(5);
        when(mockCalculadora.multiplicar(5, 2)).thenReturn(10);

        // Act
        int resultado = servicio.dobleDeLaSuma(3, 2);

        // Assert
        assertEquals(10, resultado);

        // Verify: comprobamos que el servicio llamó al mock con los argumentos correctos
        verify(mockCalculadora).sumar(3, 2);
        verify(mockCalculadora).multiplicar(5, 2);
    }

    // -------------------------------------------------------------------------
    // restaAlCuadrado
    // -------------------------------------------------------------------------

    @Test
    void restaAlCuadrado_llamaARestarYMultiplicar_devuelveResultadoCorrecto() {
        when(mockCalculadora.restar(7, 3)).thenReturn(4);
        // El servicio pasa la diferencia como ambos factores: multiplicar(4, 4)
        when(mockCalculadora.multiplicar(4, 4)).thenReturn(16);

        assertEquals(16, servicio.restaAlCuadrado(7, 3));

        verify(mockCalculadora).restar(7, 3);
        verify(mockCalculadora).multiplicar(4, 4);
    }

    // -------------------------------------------------------------------------
    // sumaYDivide
    // -------------------------------------------------------------------------

    @Test
    void sumaYDivide_divisorValido_devuelveCociente() {
        when(mockCalculadora.sumar(10, 5)).thenReturn(15);
        when(mockCalculadora.dividir(15, 3)).thenReturn(5);

        assertEquals(5, servicio.sumaYDivide(10, 5, 3));
    }

    /**
     * thenThrow hace que el mock lance una excepción en lugar de devolver un valor.
     * El servicio no la captura, así que se propaga directamente al test.
     */
    @Test
    void sumaYDivide_divisorCero_propagaArithmeticException() {
        when(mockCalculadora.sumar(4, 6)).thenReturn(10);
        when(mockCalculadora.dividir(10, 0)).thenThrow(new ArithmeticException("División entre cero"));

        assertThrows(ArithmeticException.class,
                () -> servicio.sumaYDivide(4, 6, 0));
    }
}
