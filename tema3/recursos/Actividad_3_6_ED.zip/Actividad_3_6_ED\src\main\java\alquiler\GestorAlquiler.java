package alquiler;

public class GestorAlquiler {

    private final CalculadoraTarifa calculadora;
    private final VehiculoRepository repositorio;

    public GestorAlquiler(CalculadoraTarifa calculadora, VehiculoRepository repositorio) {
        this.calculadora = calculadora;
        this.repositorio = repositorio;
    }

    /**
     * Procesa una solicitud de alquiler.
     *
     * @param tipoVehiculo tipo de vehículo solicitado
     * @param dias         días de alquiler
     * @param seguro       true si el cliente quiere seguro
     * @return precio total si el vehículo está disponible
     * @throws IllegalArgumentException si los parámetros son inválidos para CalculadoraTarifa
     * @throws IllegalStateException    si el vehículo no está disponible
     *
     * Regla adicional: si el vehículo tiene más de 100.000 km aplica un 10% de descuento.
     */
    public double procesarAlquiler(String tipoVehiculo, int dias, boolean seguro) {
        // TODO: implementar
        return 0;
    }
}
