﻿import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EjemploTest {

    private Conversor conversor;

    @BeforeEach
    void setUp() {
        conversor = new Conversor();
    }

    @Test
    void celsiusAFahrenheit_congelacionDelAgua() {
        assertEquals(32.0, conversor.celsiusAFahrenheit(0));
    }

    @Test
    void celsiusAFahrenheit_ebullicionDelAgua() {
        assertEquals(212.0, conversor.celsiusAFahrenheit(100));
    }

    @Test
    void celsiusAFahrenheit_temperaturaInvalida_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class,
                () -> conversor.celsiusAFahrenheit(-300));
    }

    @Test
    void kmAMillas_valorNormal() {
        assertEquals(6.2, conversor.kmAMillas(10));
    }

    @Test
    void kmAMillas_distanciaCero() {
        assertEquals(0.0, conversor.kmAMillas(0));
    }

    @Test
    void kmAMillas_distanciaNegativa_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class,
                () -> conversor.kmAMillas(-1));
    }
}
