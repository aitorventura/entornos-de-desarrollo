import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GestorCalificacionesTest {

    private GestorCalificaciones gestor;

    @BeforeEach
    void setUp() {
        gestor = new GestorCalificaciones();
    }

    // ── calcularNotaFinal ──────────────────────────────────────────────────
    // TODO: añade aqui los tests para calcularNotaFinal
    //   Recuerda cubrir: calculo normal (60/40), porcentaje 0, porcentaje 100,
    //   nota examen invalida, nota practica invalida, porcentaje invalido.


    // ── obtenerCalificacion ───────────────────────────────────────────────
    // TODO: añade aqui los tests para obtenerCalificacion
    //   Recuerda cubrir todos los rangos (Suspenso, Aprobado, Bien, Notable,
    //   Sobresaliente) y los casos invalidos (nota < 0, nota > 10).


    // ── necesitaRecuperacion ──────────────────────────────────────────────
    // TODO: añade aqui los tests para necesitaRecuperacion
    //   Recuerda cubrir: aprobado sin faltas, suspenso, exceso de faltas,
    //   limites exactos y los casos que deben lanzar IllegalArgumentException.

}
