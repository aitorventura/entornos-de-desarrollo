﻿public class Conversor {

    public double celsiusAFahrenheit(double celsius) {
        if (celsius < -273.15) {
            throw new IllegalArgumentException("Temperatura inferior al cero absoluto");
        }
        return Math.round((celsius * 9.0 / 5.0 + 32) * 10.0) / 10.0;
    }

    public double kmAMillas(double km) {
        if (km < 0) {
            throw new IllegalArgumentException("La distancia no puede ser negativa");
        }
        return Math.round(km * 0.621371 * 10.0) / 10.0;
    }
}
