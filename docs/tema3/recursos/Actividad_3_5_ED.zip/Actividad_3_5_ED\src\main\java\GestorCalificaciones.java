public class GestorCalificaciones {

    /**
     * Calcula la nota final ponderada.
     *
     * @param notaExamen        nota del examen   [0.0 .. 10.0]
     * @param notaPractica      nota de practicas [0.0 .. 10.0]
     * @param porcentajeExamen  peso del examen sobre 100 [0 .. 100]
     * @return nota final redondeada a 1 decimal,
     *         o -1.0 si algun parametro esta fuera de rango
     */
    public double calcularNotaFinal(double notaExamen,
                                    double notaPractica,
                                    int porcentajeExamen) {
        // TODO: implementar
        return 0;
    }

    /**
     * Convierte una nota numerica en calificacion textual.
     *
     * @param nota valor numerico [0.0 .. 10.0]
     * @return "Suspenso"      si nota < 5.0
     *         "Aprobado"      si 5.0 <= nota < 6.0
     *         "Bien"          si 6.0 <= nota < 7.0
     *         "Notable"       si 7.0 <= nota < 9.0
     *         "Sobresaliente" si nota >= 9.0
     *         "Error"         si nota < 0.0 o nota > 10.0
     */
    public String obtenerCalificacion(double nota) {
        // TODO: implementar
        return null;
    }

    /**
     * Indica si el alumno necesita ir a recuperacion.
     *
     * @param nota      nota final del alumno [0.0 .. 10.0]
     * @param faltas    numero de faltas de asistencia [0 ..)
     * @param maxFaltas numero maximo de faltas permitido [1 ..)
     * @return true  si nota < 5.0 O faltas > maxFaltas
     *         false si nota >= 5.0 Y faltas <= maxFaltas
     * @throws IllegalArgumentException si nota < 0, nota > 10 o maxFaltas < 1
     */
    public boolean necesitaRecuperacion(double nota, int faltas, int maxFaltas) {
        // TODO: implementar
        return false;
    }
}
