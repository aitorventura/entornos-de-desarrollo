import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

class CalculadoraTarifaTest {

    private final CalculadoraTarifa calculadora = new CalculadoraTarifa();

    // TODO: implementa aqui un test parametrizado con @CsvSource
    //   que cubra todos los casos de la tabla de la actividad:
    //   tipos validos (COCHE, MOTO, FURGONETA), con y sin seguro,
    //   distintos numeros de dias, y casos invalidos (dias=0, dias=366,
    //   tipo desconocido, tipo null).
    //
    // Ejemplo de estructura:
    //
    // @ParameterizedTest
    // @CsvSource({
    //     "COCHE, 1, false, 40.0",
    //     "COCHE, 1, true,  46.0"
    // })
    // void calcularPrecio_devuelveResultadoCorrecto(
    //         String tipo, int dias, boolean seguro, double esperado) {
    //     assertEquals(esperado, calculadora.calcularPrecio(tipo, dias, seguro), 0.01);
    // }

}
