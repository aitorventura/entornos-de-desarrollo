import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GestorAlquilerTest {

    private VehiculoRepository repositorioMock;
    private CalculadoraTarifa calculadora;
    private GestorAlquiler gestor;

    @BeforeEach
    void setUp() {
        repositorioMock = mock(VehiculoRepository.class);
        calculadora = new CalculadoraTarifa();
        gestor = new GestorAlquiler(calculadora, repositorioMock);
    }

    // TODO: implementa los tests usando el mock de VehiculoRepository.
    //   Casos que debes cubrir:
    //   1. Alquiler OK sin descuento por km (km <= 100.000)
    //   2. Alquiler OK con descuento del 10% (km > 100.000)
    //   3. Vehiculo no disponible -> IllegalStateException
    //   4. Parametros invalidos   -> IllegalArgumentException
    //   5. Verificar con verify() que se llama a estaDisponible()
    //
    // Ejemplo de estructura:
    //
    // @Test
    // void procesarAlquiler_vehiculoNoDisponible_lanzaExcepcion() {
    //     when(repositorioMock.estaDisponible("COCHE")).thenReturn(false);
    //     assertThrows(IllegalStateException.class,
    //         () -> gestor.procesarAlquiler("COCHE", 2, false));
    // }

}
