public class Ejemplo1 {
    public String esAdmitido(int porcentaje){
        if(porcentaje >= 50 && porcentaje <= 90){
            return "SI";
        }
        return "NO";
    }
}
