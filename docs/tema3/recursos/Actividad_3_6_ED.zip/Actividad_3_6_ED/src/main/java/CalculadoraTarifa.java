public class CalculadoraTarifa {

    /**
     * Calcula el precio total del alquiler.
     *
     * @param tipoVehiculo "COCHE", "MOTO" o "FURGONETA"
     * @param dias         numero de dias [1 .. 365]
     * @param seguro       true = incluir seguro (+15% sobre el precio base)
     * @return precio total (> 0.0), o -1.0 si algun parametro es invalido
     *
     * Tarifas base por dia:
     *   COCHE     -> 40.00 euros
     *   MOTO      -> 25.00 euros
     *   FURGONETA -> 65.00 euros
     */
    public double calcularPrecio(String tipoVehiculo, int dias, boolean seguro) {
        // TODO: implementar
        return 0;
    }
}
