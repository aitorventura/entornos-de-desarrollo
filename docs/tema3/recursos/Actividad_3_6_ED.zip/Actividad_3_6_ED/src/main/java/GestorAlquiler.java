public class GestorAlquiler {

    private final CalculadoraTarifa calculadora;
    private final VehiculoRepository repositorio;

    public GestorAlquiler(CalculadoraTarifa calculadora, VehiculoRepository repositorio) {
        this.calculadora = calculadora;
        this.repositorio = repositorio;
    }

    /**
     * Procesa una solicitud de alquiler.
     *
     * @param tipoVehiculo tipo de vehiculo solicitado
     * @param dias         dias de alquiler
     * @param seguro       true si el cliente quiere seguro
     * @return precio total si el vehiculo esta disponible
     * @throws IllegalStateException    si el vehiculo no esta disponible
     * @throws IllegalArgumentException si los parametros son invalidos para CalculadoraTarifa
     *
     * Regla adicional: si el vehiculo tiene mas de 100.000 km aplica un 10% de descuento.
     */
    public double procesarAlquiler(String tipoVehiculo, int dias, boolean seguro) {
        // TODO: implementar
        return 0;
    }
}
