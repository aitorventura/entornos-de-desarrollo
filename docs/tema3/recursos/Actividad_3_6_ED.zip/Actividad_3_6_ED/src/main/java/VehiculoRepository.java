public interface VehiculoRepository {

    /** Devuelve true si hay al menos una unidad disponible del tipo indicado. */
    boolean estaDisponible(String tipoVehiculo);

    /** Devuelve los kilometros del vehiculo disponible (para aplicar descuento por uso). */
    int getKilometros(String tipoVehiculo);
}
